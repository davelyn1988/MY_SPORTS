package com.mysports

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController

class SportsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_sports, container, false)


        view.findViewById<Button>(R.id.btn_basketball).setOnClickListener {
            findNavController().navigate(R.id.action_sportsFragment_to_basketballFragment)
        }


        view.findViewById<Button>(R.id.btn_football).setOnClickListener {
            findNavController().navigate(R.id.action_sportsFragment_to_footballFragment)
        }


        view.findViewById<Button>(R.id.btn_tennis).setOnClickListener {
            findNavController().navigate(R.id.action_sportsFragment_to_tennisFragment)
        }

        return view
    }
}
